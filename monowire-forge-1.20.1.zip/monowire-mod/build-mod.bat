@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo   Monowire mod - build
echo ============================================

set "JDK_DIR=%~dp0.jdk17"
if exist "%JDK_DIR%\bin\java.exe" goto havejdk

echo Downloading portable JDK 17 into this folder, about 190 MB.
echo Nothing will be installed into the system.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri 'https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse' -OutFile 'jdk17.zip'; if (Test-Path '.jdk17_tmp') { Remove-Item '.jdk17_tmp' -Recurse -Force }; Expand-Archive -Path 'jdk17.zip' -DestinationPath '.jdk17_tmp' -Force; $d = Get-ChildItem '.jdk17_tmp' -Directory | Select-Object -First 1; Move-Item $d.FullName '.jdk17'; Remove-Item '.jdk17_tmp' -Recurse -Force; Remove-Item 'jdk17.zip' -Force"

if not exist "%JDK_DIR%\bin\java.exe" goto jdkfail

:havejdk
set "JAVA_HOME=%JDK_DIR%"
set "PATH=%JDK_DIR%\bin;%PATH%"
java -version

call gradlew.bat build
if errorlevel 1 goto buildfail

echo.
echo DONE! Your mod: build\libs\monowire-1.0.0.jar
explorer "build\libs"
pause
exit /b 0

:jdkfail
echo.
echo [ERROR] Could not download JDK 17. Check internet or VPN and run again.
pause
exit /b 1

:buildfail
echo.
echo [ERROR] Build failed. Send the text above to the assistant.
pause
exit /b 1
