package com.monowire.registry;

import com.monowire.MonowireMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MonowireMod.MODID);

    public static final RegistryObject<SoundEvent> MONOWIRE_SWING = register("monowire_swing");
    public static final RegistryObject<SoundEvent> MONOWIRE_HIT = register("monowire_hit");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MonowireMod.MODID, name)));
    }

    private ModSounds() {}
}
