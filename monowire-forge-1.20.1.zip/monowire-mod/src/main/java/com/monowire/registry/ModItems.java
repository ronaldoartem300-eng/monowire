package com.monowire.registry;

import com.monowire.MonowireMod;
import com.monowire.item.ModTiers;
import com.monowire.item.MonowireItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MonowireMod.MODID);

    // Урон: 1 (рука) + 3 (модификатор) + 3 (тир) = 7, скорость атаки 2.0
    public static final RegistryObject<Item> MONOWIRE = ITEMS.register("monowire",
            () -> new MonowireItem(ModTiers.MONOWIRE, 3, -2.0F,
                    new Item.Properties().rarity(Rarity.RARE)));

    private ModItems() {}
}
