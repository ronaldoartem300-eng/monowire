package com.monowire.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.monowire.registry.ModEffects;
import com.monowire.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

/**
 * Моноструна (Monowire).
 * ЛКМ  — удар с дальностью 6 блоков, задевает врагов вокруг цели, вызывает кровотечение.
 * ПКМ  — хлёст дугой перед собой на 6 блоков (перезарядка 1.5 с).
 */
public class MonowireItem extends SwordItem {
    private static final UUID REACH_UUID = UUID.fromString("c3a7e8d2-4b1f-4f6a-9d2e-7a1b5c9e3f10");

    public static final double EXTRA_REACH = 3.0;       // 3 (база) + 3 = 6 блоков
    public static final double SPLASH_RADIUS = 2.5;     // радиус задевания вокруг цели
    public static final float SPLASH_DAMAGE_MULT = 0.6F;
    public static final double WHIP_RANGE = 6.0;
    public static final double WHIP_CONE_COS = 0.64;    // ~50° в каждую сторону
    public static final float WHIP_DAMAGE_MULT = 0.8F;
    public static final int WHIP_COOLDOWN = 30;         // тиков

    private static final DustParticleOptions WIRE_GLOW =
            new DustParticleOptions(new Vector3f(1.0F, 0.45F, 0.1F), 0.8F);

    private Multimap<Attribute, AttributeModifier> mainHandModifiers;

    public MonowireItem(Tier tier, int attackDamage, float attackSpeed, Properties properties) {
        super(tier, attackDamage, attackSpeed, properties);
    }

    // ---------- Атрибуты: добавляем дальность атаки ----------

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot != EquipmentSlot.MAINHAND) {
            return super.getDefaultAttributeModifiers(slot);
        }
        if (mainHandModifiers == null) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.putAll(super.getDefaultAttributeModifiers(slot));
            builder.put(ForgeMod.ENTITY_REACH.get(), new AttributeModifier(REACH_UUID,
                    "Monowire reach", EXTRA_REACH, AttributeModifier.Operation.ADDITION));
            mainHandModifiers = builder.build();
        }
        return mainHandModifiers;
    }

    // Отключаем ванильный взмах меча — у нас свой удар по площади
    @Override
    public boolean canPerformAction(ItemStack stack, ToolAction action) {
        return action != ToolActions.SWORD_SWEEP && super.canPerformAction(stack, action);
    }

    // ---------- ЛКМ: удар по цели + задевание соседей ----------

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        Level level = attacker.level();
        if (!level.isClientSide) {
            target.addEffect(new MobEffectInstance(ModEffects.BLEEDING.get(), 100, 0), attacker);

            float splashDamage = (float) attacker.getAttributeValue(Attributes.ATTACK_DAMAGE) * SPLASH_DAMAGE_MULT;
            DamageSource source = damageSource(attacker);
            AABB area = target.getBoundingBox().inflate(SPLASH_RADIUS, 1.0, SPLASH_RADIUS);
            float yawRad = attacker.getYRot() * Mth.DEG_TO_RAD;

            for (LivingEntity other : level.getEntitiesOfClass(LivingEntity.class, area,
                    e -> e != target && canHit(attacker, e))) {
                if (other.hurt(source, splashDamage)) {
                    other.addEffect(new MobEffectInstance(ModEffects.BLEEDING.get(), 60, 0), attacker);
                    other.knockback(0.3, Mth.sin(yawRad), -Mth.cos(yawRad));
                }
            }

            level.playSound(null, target.getX(), target.getY(), target.getZ(),
                    ModSounds.MONOWIRE_HIT.get(), SoundSource.PLAYERS,
                    1.0F, 0.9F + level.random.nextFloat() * 0.2F);

            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK,
                        target.getX(), target.getY(0.5), target.getZ(), 1, 0, 0, 0, 0);
                serverLevel.sendParticles(WIRE_GLOW,
                        target.getX(), target.getY(0.5), target.getZ(), 12, 0.6, 0.3, 0.6, 0);
            }
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    // ---------- ПКМ: хлёст дугой ----------

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            whip(level, player);
            stack.hurtAndBreak(2, player, p -> p.broadcastBreakEvent(hand));
        }
        player.getCooldowns().addCooldown(this, WHIP_COOLDOWN);
        player.awardStat(Stats.ITEM_USED.get(this));
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private void whip(Level level, Player player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        float damage = (float) player.getAttributeValue(Attributes.ATTACK_DAMAGE) * WHIP_DAMAGE_MULT;
        DamageSource source = player.damageSources().playerAttack(player);
        AABB area = player.getBoundingBox().inflate(WHIP_RANGE);
        int hits = 0;

        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area, e -> canHit(player, e))) {
            Vec3 toTarget = target.getBoundingBox().getCenter().subtract(eye);
            double dist = toTarget.length();
            if (dist < 1.0E-3 || dist > WHIP_RANGE + target.getBbWidth() * 0.5) continue;
            if (toTarget.normalize().dot(look) < WHIP_CONE_COS) continue;
            if (!player.hasLineOfSight(target)) continue;

            if (target.hurt(source, damage)) {
                hits++;
                target.addEffect(new MobEffectInstance(ModEffects.BLEEDING.get(), 160, 1), player);
                target.knockback(0.5, -toTarget.x, -toTarget.z);
            }
        }

        if (level instanceof ServerLevel serverLevel) {
            for (int i = -5; i <= 5; i++) {
                Vec3 dir = look.yRot(i * 9.0F * Mth.DEG_TO_RAD);
                for (double d = 1.5; d <= WHIP_RANGE; d += 1.0) {
                    Vec3 p = eye.add(dir.scale(d));
                    serverLevel.sendParticles(WIRE_GLOW, p.x, p.y - 0.2, p.z, 1, 0, 0, 0, 0);
                }
            }
            Vec3 mid = eye.add(look.scale(2.5));
            serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK, mid.x, mid.y - 0.2, mid.z, 3, 0.8, 0.1, 0.8, 0);
        }

        if (hits > 0) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.MONOWIRE_HIT.get(), SoundSource.PLAYERS, 1.0F, 0.8F);
        }
    }

    // ---------- Звук взмаха (ЛКМ и ПКМ) ----------

    @Override
    public boolean onEntitySwing(ItemStack stack, LivingEntity entity) {
        Level level = entity.level();
        if (!level.isClientSide) {
            level.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                    ModSounds.MONOWIRE_SWING.get(), SoundSource.PLAYERS,
                    0.7F, 0.9F + level.random.nextFloat() * 0.25F);
        }
        return false;
    }

    // ---------- Вспомогательное ----------

    private static boolean canHit(LivingEntity attacker, LivingEntity e) {
        if (e == attacker || !e.isAlive() || e.isSpectator()) return false;
        if (attacker.isAlliedTo(e)) return false;
        if (e instanceof ArmorStand stand && stand.isMarker()) return false;
        if (e instanceof TamableAnimal pet && pet.isOwnedBy(attacker)) return false;
        return true;
    }

    private static DamageSource damageSource(LivingEntity attacker) {
        return attacker instanceof Player player
                ? attacker.damageSources().playerAttack(player)
                : attacker.damageSources().mobAttack(attacker);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.monowire.monowire.lmb").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.monowire.monowire.rmb").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.monowire.monowire.bleed").withStyle(ChatFormatting.DARK_RED));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
