package com.monowire.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

public enum ModTiers implements Tier {
    MONOWIRE;

    @Override public int getUses() { return 1800; }
    @Override public float getSpeed() { return 1.0F; }
    @Override public float getAttackDamageBonus() { return 3.0F; }
    @Override public int getLevel() { return 3; }
    @Override public int getEnchantmentValue() { return 18; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.DIAMOND); }
}
