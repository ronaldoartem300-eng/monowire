package com.monowire.effect;

import com.monowire.registry.ModDamageTypes;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

/**
 * Кровотечение: периодический урон, игнорирующий броню.
 * Уровень I  — 1 ед. урона каждые 25 тиков,
 * Уровень II — 1.5 ед. каждые 20 тиков и т.д.
 */
public class BleedingEffect extends MobEffect {
    private static final DustParticleOptions BLOOD =
            new DustParticleOptions(new Vector3f(0.55F, 0.0F, 0.0F), 1.2F);

    public BleedingEffect() {
        super(MobEffectCategory.HARMFUL, 0x8A0303);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        Level level = entity.level();
        if (level.isClientSide) {
            return;
        }
        // Чтобы тик кровотечения не "съедался" неуязвимостью после удара
        entity.invulnerableTime = 0;
        entity.hurt(ModDamageTypes.bleeding(level), 1.0F + amplifier * 0.5F);

        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(BLOOD,
                    entity.getX(), entity.getY() + entity.getBbHeight() * 0.6, entity.getZ(),
                    8,
                    entity.getBbWidth() * 0.3, entity.getBbHeight() * 0.25, entity.getBbWidth() * 0.3,
                    0.0);
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        int interval = Math.max(10, 25 - amplifier * 5);
        return duration % interval == 0;
    }
}
