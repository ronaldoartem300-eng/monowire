# Свои звуки моноструны

Здесь синтезированные звуки (электрический свист и металлический «дзынь» при разрезе) в формате WAV.
Minecraft читает только **OGG Vorbis**, поэтому по умолчанию мод использует ванильные звуки с изменённой высотой тона.

Чтобы включить свои звуки:
1. Сконвертируй каждый `.wav` в `.ogg` (Audacity: Файл → Экспорт → OGG, моно; или `ffmpeg -i x.wav -ac 1 -c:a libvorbis x.ogg`).
2. Положи `.ogg` в `src/main/resources/assets/monowire/sounds/`.
3. Замени `src/main/resources/assets/monowire/sounds.json` файлом `sounds.json` из этой папки.
4. Пересобери мод.
